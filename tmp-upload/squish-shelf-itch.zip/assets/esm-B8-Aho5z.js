const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DGN35mzD.js","./index-C8jPxxvz.js","./index-Bx2XYn04.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C8jPxxvz.js";const _=r("Share",{web:()=>t(()=>import("./web-DGN35mzD.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
